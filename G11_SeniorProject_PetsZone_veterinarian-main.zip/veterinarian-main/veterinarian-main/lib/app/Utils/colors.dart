import 'package:flutter/material.dart';

//UI Colors
const Color messageByMeColor = Color(0xff6c5ce7);
const Color messageByOtherColor = Color.fromARGB(255, 196, 151, 241);
const Color circelAvatarCartColor = Colors.white;
const Color txtFontColor = Colors.white;
//pick Color vlaue
const appBarColor = "#00134d";
const addToCartColor = "#00134d";
const txtAnimalStaffColor = "#00134d";
const imgAnimalStaffColor = "#00134d";
