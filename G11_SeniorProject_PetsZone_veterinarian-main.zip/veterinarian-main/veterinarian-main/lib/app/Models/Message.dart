class Message {
  String message;
  String sendByme;
  String time;

  Message({required this.message, required this.sendByme, required this.time});
  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
        message: json["message"],
        sendByme: json["sendByme"],
        time: json["time"]);
  }
}
