import 'package:flutter/material.dart';
import 'package:ped_zone_app/app/Utils/colors.dart';

class MessageItem extends StatelessWidget {
  //defiend veriable for time message and sendByme
  bool? sendByme;
  String? message;
  String? time;
  //passing it to constroctor
  MessageItem(
      {required this.sendByme, required this.message, required this.time});

  @override
  Widget build(BuildContext context) {
    //used Align widget to  showing left or
    // right messageView depends of sendBy me or not
    return Align(
      alignment:
          sendByme == true ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(9),
            color: sendByme == true ? messageByMeColor : messageByOtherColor),
        padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
        margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 5),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              message.toString(),
              style: TextStyle(
                  color: sendByme == true ? Colors.white : Colors.white,
                  fontSize: 18),
            ),
            const SizedBox(
              width: 5,
            ),
            Text(
              time.toString(),
              style: TextStyle(
                  color: sendByme == true ? Colors.white : Colors.white,
                  fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}
