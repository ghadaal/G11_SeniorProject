import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ped_zone_app/app/modules/ChatScreen/controllers/chat_screen_controller.dart';
import 'package:ped_zone_app/app/modules/ChatScreen/views/UIComponets/MessageUI.dart';

// ignore: non_constant_identifier_names
Widget ListMessageUI(BuildContext context) {
  //Get data  From Chat Controller and display it
  ChatScreenController controller = Get.put(ChatScreenController());
  return Expanded(
      flex: 8,
      child: Obx(
        () => Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
                image: AssetImage(
                  "assets/images/bg.jpg",
                ),
                fit: BoxFit.cover),
          ),
          child: ListView.builder(
            /*
            showing all message on conversation
            */
              itemCount: controller.chatMessages.length,
              itemBuilder: (context, index) {
                var currentItem = controller.chatMessages[index];
                return MessageItem(
                  sendByme: currentItem.sendByme == controller.socket.id,
                  message: currentItem.message,
                  // ignore: prefer_interpolation_to_compose_strings
                  time: currentItem.time + "PM",
                );
              }),
        ),
      ));
}
