import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:ped_zone_app/app/Utils/colors.dart';
import 'package:ped_zone_app/app/Utils/toColor.dart';
import 'package:ped_zone_app/app/modules/ChatScreen/views/UIComponets/LIstMessageUI.dart';

import '../controllers/chat_screen_controller.dart';
import 'UIComponets/SendMessageUI.dart';

class ChatScreenView extends GetView<ChatScreenController> {
  const ChatScreenView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: appBarColor.toColor(),
        title: const Center(child: Text("Chat Veterinarian")),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        child: Container(
          child: Column(
            children: [ListMessageUI(context), SendMessageUI(context)],
          ),
        ),
      ),
    );
  }
}
