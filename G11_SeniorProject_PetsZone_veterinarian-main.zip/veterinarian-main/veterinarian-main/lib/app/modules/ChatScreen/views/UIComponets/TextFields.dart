import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ped_zone_app/app/Utils/toColor.dart';
import 'package:ped_zone_app/app/modules/ChatScreen/controllers/chat_screen_controller.dart';

Widget TextFormFiledUI(BuildContext context,
    {@required String? Name, @required TextEditingController? controller}) {
      //Get data form ChatSreenController
  ChatScreenController chatScreenController = Get.put(ChatScreenController());

  return TextFormField(
    scrollPhysics:
        const NeverScrollableScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
    controller: controller,
    keyboardType: TextInputType.name,
    textAlign: TextAlign.center,
    minLines: 1,
    maxLines: 4,

    onSaved: (value) {
      //used here if want to save message in DB 
    },
    validator: (value) {
      //if you have condition on messages text

    },
    style: const TextStyle(//style for message text
      fontWeight: FontWeight.bold,
      fontSize: 14,
    ),
    decoration: InputDecoration(
      hintTextDirection: TextDirection.rtl,
      suffixIcon: Padding(
        padding: const EdgeInsets.all(8.0),
        child: InkWell(
          onTap: () {
            chatScreenController
                .sendMessage(chatScreenController.msgInputController.text);
            chatScreenController.msgInputController.text = "";
          },
          child: Image.asset(
            "assets/images/sendMessage.png",
            height: 40,
            width: 40,
          ),
        ),
      ),
      hintText: Name,
      hintStyle: const TextStyle(
        leadingDistribution: TextLeadingDistribution.even,
        fontSize: 12,
        fontWeight: FontWeight.bold,
      ),
      contentPadding: const EdgeInsets.all(10),
      border: InputBorder.none,

    /*
    next there are Borders of state of TextFields 
    onEnbaleBorder => means when u showup the TextFileds
    errorBorder=> means if u make validtor above and user make mistake
    focusedBorder=> means  u pressed to type something
    */
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: "#073b4c".toColor()),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(
          color: Colors.tealAccent,
          style: BorderStyle.solid,
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(
          style: BorderStyle.solid,
        ),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(
          color: Colors.tealAccent,
          style: BorderStyle.solid,
        ),
      ),
      errorStyle: const TextStyle(
        color: Colors.red,
      ),
    ),
  );
}
