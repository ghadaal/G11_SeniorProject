import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ped_zone_app/app/modules/ChatScreen/controllers/chat_screen_controller.dart';
import 'package:ped_zone_app/app/modules/ChatScreen/views/UIComponets/TextFields.dart';

Widget SendMessageUI(BuildContext context) {
  //SendMessage UI  iclude TextFormFileds to get message form user
  ChatScreenController controller = Get.put(ChatScreenController());
  return Container(
      height: 70,
      padding: const EdgeInsets.only(top: 7, right: 3, left: 3),
      
          child: TextFormFiledUI(context,
              Name: "type something",
              controller: controller.msgInputController));
}
