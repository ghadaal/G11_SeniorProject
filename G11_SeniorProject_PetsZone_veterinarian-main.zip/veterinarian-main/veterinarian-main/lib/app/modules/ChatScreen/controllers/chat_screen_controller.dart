import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:ped_zone_app/app/Models/Message.dart';
import 'package:socket_io_client/socket_io_client.dart' as Io;

class ChatScreenController extends GetxController {

  //defiend TextEdittiong controller =>for message TextFields
  TextEditingController msgInputController = TextEditingController();
  //defiend socket io to make tunnel between sender and recever 
  late Io.Socket socket;
  //chatmessage from message models
  var chatMessages = <Message>[].obs;

//connect user to check if socket working fine or not
  var connectedUser = 0.obs;

  @override
  void onInit() {
//init socket on 
    socket = Io.io(
        "http://172.20.10.2:4000",//here change IP to Your IP network WiFI

        Io.OptionBuilder()
            .setTransports(['websocket'])
            .disableAutoConnect() // disable auto-connection
            .build());
    socket.connect();
    socket.onConnect((_) {
      print("connect");
    });
    setUpSocketListener();
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void setUpSocketListener() {
    socket.on('message-receive', (data) {
      print(data);//when message be Ready
      chatMessages.add(Message.fromJson(data));
    });
  }

  void sendMessage(String text) {
    DateTime now = DateTime.now();

    var formatter = new DateFormat('hh-mm');//formater for time messaging
    String formattedDate = formatter.format(now);

    var messagejson = {
      "message": text,//add txt message
      "sendByme": socket.id,//userId to get if he send by me or not
      "time": formattedDate//time for message
    };
    socket.emit('message', messagejson);//send message to server
    chatMessages.add(Message.fromJson(messagejson));
  }
}
