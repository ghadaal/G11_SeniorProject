import 'package:get/get.dart';
import 'package:ped_zone_app/app/modules/ChatScreen/controllers/chat_screen_controller.dart';

class ChatScreenBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ChatScreenController>(
      () => ChatScreenController(),
    );
  }
}
