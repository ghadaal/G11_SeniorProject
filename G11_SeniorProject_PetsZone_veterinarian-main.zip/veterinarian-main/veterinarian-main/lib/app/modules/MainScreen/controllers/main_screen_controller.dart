import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mocktail/mocktail.dart';

class MainScreenController extends GetxController {
//drawer area
  var scaffoldKey = GlobalKey<ScaffoldState>();
  void openDrawer() {
    scaffoldKey.currentState!.openEndDrawer();
  }

  void closeDrawer() {
    scaffoldKey.currentState!.openEndDrawer();
  }
//End Drawer Area

//Demo Data For animal List
  final List<Map> animalList = [
    {"animalName": "Dogs"},
    {"animalName": "Cats"},
    {"animalName": "Rabbit"},
  ];
  final List<Map> animalImages = [
    {"img": "assets/images/dogimg.png"},
    {"img": "assets/images/catimg.jpg"},
    {"img": "assets/images/rabbit.png"},
  ];

  final List<Map> animlStaffList = [
    {"staffName": "Pits House"},
    {"staffName": "Pits House"},
    {"staffName": "Pits House"},
  ];
  final List<Map> animlStaffPrice = [
    {"price": "3000 SAR"},
    {"price": "200 SAR"},
    {"price": "4000 SAR"},
  ];
  final List<Map> animalStaffImages = [
    {"img": "assets/images/item1.png"},
    {"img": "assets/images/item2.jpg"},
    {"img": "assets/images/item3.jpg"},
  ];
//End  Demo Data

//concept
  var isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();

    Future.delayed(Duration(seconds: 5), () {
      isLoading.value = true;
    });
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}

//TDD Phase

class MockController extends GetxService
    with Mock
    implements MainScreenController {}

main() {
  late MockController mockController;
  setUpAll(() {
    mockController = MockController();
  });
}

void setUpAll(Null Function() param0) {}
