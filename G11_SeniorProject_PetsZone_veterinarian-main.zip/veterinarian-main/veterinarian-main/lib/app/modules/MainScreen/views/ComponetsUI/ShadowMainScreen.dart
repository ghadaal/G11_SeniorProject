import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:ped_zone_app/app/Utils/colors.dart';
import 'package:ped_zone_app/app/modules/MainScreen/controllers/main_screen_controller.dart';
import 'package:shimmer/shimmer.dart';

class MyContentDashboardEffect extends StatelessWidget {
  const MyContentDashboardEffect({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    MainScreenController controller = Get.put(MainScreenController());

    return Shimmer.fromColors(
        baseColor: Colors.grey[500]!,
        highlightColor: Colors.white,
        child: Container(
            height: ScreenUtil.defaultSize.height,
            child: Column(
              children: [
                Container(
                  height: 150.sp,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    // implement GridView.builder
                    child: GridView.builder(
                        scrollDirection: Axis.horizontal,
                        gridDelegate:
                            const SliverGridDelegateWithMaxCrossAxisExtent(
                                maxCrossAxisExtent: 250,
                                childAspectRatio: 2 / 2,
                                crossAxisSpacing: 10,
                                mainAxisSpacing: 10),
                        itemCount: controller.animalList.length,
                        itemBuilder: (BuildContext ctx, index) {
                          return Container(
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                  color: Colors.amber,
                                  borderRadius: BorderRadius.circular(15)),
                              child: Padding(
                                  padding: EdgeInsets.only(
                                      left: 10.0.sp, top: 20.sp),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CircleAvatar(
                                        radius: 40,
                                        backgroundColor: Colors.white,
                                        child: Image.asset(
                                          controller.animalImages[index]['img'],
                                          height: 50.sp,
                                          width: 60.sp,
                                        ),
                                      ),
                                      Text(
                                        controller.animalList[index]
                                            ['animalName'],
                                        style: const TextStyle(
                                            color: txtFontColor,
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  )));
                        }),
                  ),
                ),
              ],
            )));
  }
}
