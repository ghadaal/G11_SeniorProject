import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:get/get.dart';
import 'package:ped_zone_app/app/Utils/colors.dart';
import 'package:ped_zone_app/app/Utils/toColor.dart';
import 'package:ped_zone_app/app/modules/MainScreen/views/ComponetsUI/AnimalStaff.dart';
import 'package:ped_zone_app/app/modules/MainScreen/views/ComponetsUI/MainDrawerUI.dart';
import 'package:ped_zone_app/app/modules/MainScreen/views/ComponetsUI/ShadowMainScreen.dart';

import '../controllers/main_screen_controller.dart';
import 'ComponetsUI/AnimalCardList.dart';
import 'ComponetsUI/AppBar.dart';

class MainScreenView extends GetView<MainScreenController> {
  const MainScreenView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(360, 690),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (BuildContext context, child) => MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          appBar: AppBarWidget(),
          key: controller.scaffoldKey,
          endDrawer: MainDrawer(),
          body: SingleChildScrollView(
              child: Obx(() => Column(
                    children: [
                      SizedBox(
                          height: ScreenUtil.defaultSize.height / 3,
                          child: controller.isLoading == false
                              ? MyContentDashboardEffect()
                              : AnimalCardList()),
                      Padding(
                        padding: EdgeInsets.only(
                            right: ScreenUtil.defaultSize.width / 2,
                            top: 20.sp),
                        child: Text(
                          "Animal Staff",
                          style: TextStyle(
                              color: txtAnimalStaffColor.toColor(),
                              fontSize: 20.sp,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      SizedBox(
                        height: 30,
                      ),
                      controller.isLoading.value == true
                          ? AnimalStaff()
                          : MyContentDashboardEffect(),
                    ],
                  ))),
          floatingActionButton: InkWell(
              onTap: () {
                Get.toNamed("/chat-screen");
              },
              child: CircleAvatar(
                  backgroundColor: Colors.transparent,
                  radius: 40.sp,
                  child: Image.asset(
                    "assets/icons/whatspp.png",
                    height: 60.sp,
                  ))),
        ),
      ),
    );
  }
}
