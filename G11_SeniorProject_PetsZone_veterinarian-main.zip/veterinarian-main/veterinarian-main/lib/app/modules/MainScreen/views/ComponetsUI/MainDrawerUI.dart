import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:ped_zone_app/app/Utils/colors.dart';
import 'package:ped_zone_app/app/Utils/toColor.dart';
import 'package:ped_zone_app/app/modules/MainScreen/controllers/main_screen_controller.dart';

class MainDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    MainScreenController mainScreenController = Get.put(MainScreenController());
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(color: appBarColor.toColor()),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  "assets/icons/girl.png",
                  height: 60.sp,
                  width: 60.sp,
                ),
                const Text(
                  "UserName",
                  style: TextStyle(color: Colors.white),
                ),
              ],
            ),
          ),
          ListTile(
            title: Text('Home'),
            tileColor:
                Get.currentRoute == '/dashboard' ? Colors.grey[300] : null,
            onTap: () {
              print(Get.currentRoute);
              Get.back();
              Get.offNamed('/dashboard');
            },
            trailing: Image.asset(
              "assets/icons/home.png",
              height: 30.sp,
              width: 40.sp,
            ),
          ),
          ListTile(
            title: Text('Settings'),
            tileColor: Get.currentRoute == '/page1' ? Colors.grey[300] : null,
            onTap: () {
              Get.back();
              Get.offNamed('/page1');
            },
            trailing: Image.asset(
              "assets/icons/settings.png",
              height: 40.sp,
              width: 40.sp,
            ),
          ),
          ListTile(
            title: Text('Adopt'),
            tileColor: Get.currentRoute == '/page2' ? Colors.grey[300] : null,
            onTap: () {
              Get.back();
              Get.offNamed('/page2');
            },
            trailing: Image.asset(
              "assets/icons/adopt.png",
              height: 40.sp,
              width: 40.sp,
            ),
          ),
          ListTile(
            title: Text('Booking'),
            tileColor: Get.currentRoute == '/page2' ? Colors.grey[300] : null,
            onTap: () {
              mainScreenController.closeDrawer();
            },
            trailing: Image.asset(
              "assets/icons/calender.png",
              height: 90.sp,
              width: 40.sp,
            ),
          ),
          ListTile(
            title: Text('Take Photo'),
            tileColor: Get.currentRoute == '/page2' ? Colors.grey[300] : null,
            onTap: () {
              mainScreenController.closeDrawer();
            },
            trailing: Image.asset(
              "assets/icons/camera.png",
              height: 40.sp,
              width: 40.sp,
            ),
          ),
          ListTile(
            title: Text('Exit'),
            tileColor: Get.currentRoute == '/page2' ? Colors.grey[300] : null,
            onTap: () {
              mainScreenController.closeDrawer();
            },
            trailing: Image.asset(
              "assets/icons/exit.png",
              height: 40.sp,
              width: 40.sp,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: ScreenUtil.defaultSize.height / 3.5),
            child: ListTile(
              title: Text('App Version '),
              tileColor: Get.currentRoute == '/page2' ? Colors.grey[300] : null,
              onTap: () {
                mainScreenController.closeDrawer();
              },
              trailing: Text('1.0.0 '),
            ),
          ),
        ],
      ),
    );
  }
}
