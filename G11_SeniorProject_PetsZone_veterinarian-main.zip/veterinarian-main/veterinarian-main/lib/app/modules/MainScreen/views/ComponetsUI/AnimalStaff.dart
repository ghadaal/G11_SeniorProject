import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:ped_zone_app/app/Utils/colors.dart';
import 'package:ped_zone_app/app/Utils/toColor.dart';
import 'package:ped_zone_app/app/modules/MainScreen/controllers/main_screen_controller.dart';

Widget AnimalStaff() {
  MainScreenController controller = Get.put(MainScreenController());
  return Container(
      height: ScreenUtil.defaultSize.height,
      child: Column(
        children: [
          Container(
            height: 289.sp,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              // implement GridView.builder
              child: GridView.builder(
                  scrollDirection: Axis.horizontal,
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 320,
                      childAspectRatio: 4 / 2,
                      crossAxisSpacing: 5,
                      mainAxisSpacing: 5),
                  itemCount: controller.animlStaffList.length,
                  itemBuilder: (BuildContext ctx, index) {
                    return Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            color: Colors.transparent,
                            borderRadius: BorderRadius.circular(15)),
                        child: Padding(
                            padding: EdgeInsets.only(left: 10.0.sp, top: 20.sp),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CircleAvatar(
                                  radius: 40,
                                  backgroundColor: Colors.transparent,
                                  child: Image.asset(
                                    controller.animalStaffImages[index]['img'],
                                    height: 200.sp,
                                    width: 200.sp,
                                  ),
                                ),
                                Text(
                                  controller.animlStaffList[index]['staffName'],
                                  style: const TextStyle(
                                      color: Colors.black,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  controller.animlStaffPrice[index]['price'],
                                  style: const TextStyle(
                                      color: Colors.black,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold),
                                ),
                                TextButton(
                                    onPressed: () {},
                                    style: ButtonStyle(
                                      backgroundColor:
                                          MaterialStateProperty.all<Color>(
                                              addToCartColor.toColor()),
                                    ),
                                    child: const Text(
                                      "Add To Cart",
                                      style: TextStyle(
                                          color: txtFontColor,
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold),
                                    ))
                              ],
                            )));
                  }),
            ),
          ),
        ],
      ));
}
