import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:ped_zone_app/app/Utils/colors.dart';
import 'package:ped_zone_app/app/Utils/toColor.dart';
import 'package:ped_zone_app/app/modules/MainScreen/controllers/main_screen_controller.dart';

AppBarWidget() {
  MainScreenController controller = Get.put(MainScreenController());
  return PreferredSize(
      preferredSize: Size.fromHeight(120), // Set this height
      child: Container(
        color: appBarColor.toColor(),
        child: Padding(
          padding: const EdgeInsets.only(top: 20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 10.0.sp, top: 20.sp),
                    child: CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.white,
                      child: Image.asset(
                        "assets/icons/cart-empty.png",
                        height: 40.sp,
                        width: 30.sp,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 10.0.sp, top: 20.sp),
                    child: Image.asset(
                      "assets/icons/search.png",
                      height: 20.sp,
                      width: 30.sp,
                      color: Colors.white,
                    ),
                  ),
                  Spacer(
                    flex: 2,
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 10.0.sp, top: 20.sp),
                    child: Image.asset(
                      "assets/icons/cat.png",
                      height: 50.sp,
                      width: 30.sp,
                      color: Colors.white,
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsets.only(left: 10.0.sp, top: 20.sp, right: 20),
                    child: InkWell(
                      onTap: () {
                        controller.openDrawer();
                      },
                      child: Image.asset(
                        "assets/icons/menu.png",
                        height: 40.sp,
                        width: 30.sp,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ));
}
