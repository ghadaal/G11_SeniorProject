import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ped_zone_app/app/modules/Login/bindings/login_binding.dart';
import 'package:ped_zone_app/app/routes/app_pages.dart';

void main() {
  runApp(
    //init First Page
    GetMaterialApp(
      title: "Application",
      initialRoute: AppPages.INITIAL,
      getPages: AppPages.routes,
      debugShowCheckedModeBanner: false,
      initialBinding: BindingsBuilder.put(() => LoginBinding()),
    ),
  );
}
